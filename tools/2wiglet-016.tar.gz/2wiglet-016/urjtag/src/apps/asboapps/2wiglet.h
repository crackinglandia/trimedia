
#ifndef FALSE
#define FALSE (0)
#define TRUE (!(FALSE))
#endif

#define START_L2_LOAD_V1    0x12340002
#define JUMP_TO_L2_CODE     0x56780000

#define BOOTREADYWAITTIME   8000            // 8000 msec timeout waiting for L1 BOOT READY, etc

#define OFULL               2               // bitmask of JTAG CTRL1 register
#define SLEEPLESS           1               // bitmask of JTAG CTRL1 register
#define IFULL               128             // bitmask of JTAG CTRL2 register

#define OFULLFLAG           0x10            // these are the bit positions of the flags
#define IFULLFLAG           4               // when they are captured in the output from
#define SLEEPLESSFLAG       1               // shifting in an instruction

#define MAXNANDSIZE         32*1024*1024    // 2048 erase units, each with 16 pages of 512 bytes (+16 OOB)
#define MAINPAGESIZE        512
#define OOBSIZE             16
#define FULLPAGESIZE        528             // 512 bytes main page part + 16 bytes OOB

#define DEFAULTL2LOADADDR   0x40100000      // default L2 load address for 2Wire Ares CPU

struct CPU {
    char *manufacturer;
    char *partname;
    uint64_t id;
    char *stepping;
    uint32_t instrlen;
};

// { maker, partname, id, stepping, instruction length}
static const struct CPU cpu = {
     "2Wire", "Ares", 0x3269B4C1, "3" , 5};


struct TM32REG {
    char *name;
    uint32_t size;
};

static const struct TM32REG tm32regs[] = {
    {"BR",       1 },
    {"BSR",    573 },
    {"DIR",     32 },
    {"RST",      1 },
    {"DATAIN",  32 },
    {"DATAOUT", 32 },
    {"CTRL1",    8 },   // 2-bit from urjtag discovery but listed as 8-bit in NXP 8526/15xx datasheet
    {"CTRL2",    8 },   // 1-bit from urjtag discovery but listed as 8-bit in NXP 8526/15xx datasheet
    {"IFULLIN", 33 },
    {"OFULLOUT",33 },
    {"",         0 }
};

struct TM32INS {
    char *name;
    char *bitstr;
    char *reg;
};
static const struct TM32INS tm32ins[] = {
    {"EXTEST",          "00000",    "BSR"},
//  {"SAMPLE"           "00001",    "BSR"},         // pre-defined
    {"RESET",           "10000",    "RST"},         // defined in 8526 manual but non-functional in Ares
    {"BYPASS",          "11111",    "BR"},
    {"IDCODE",          "00010",    "DIR"},
    {"SELDATAIN",       "10001",    "DATAIN"},
    {"SELDATAOUT",      "10010",    "DATAOUT"},
    {"SELIFULLIN",      "10011",    "IFULLIN"},
    {"SELOFULLOUT",     "10100",    "OFULLOUT"},
    {"SELCTRL1",        "10101",    "CTRL1"},
    {"SELCTRL2",        "10110",    "CTRL2"},
    {"",                "",         ""}
};

