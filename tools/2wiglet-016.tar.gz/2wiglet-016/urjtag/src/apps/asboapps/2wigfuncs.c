#include <string.h>
#include <inttypes.h>
#include <sys/time.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <math.h>
#include <urjtag/tap_register.h>
#include <urjtag/data_register.h>
#include <urjtag/part_instruction.h>
#include <urjtag/part.h>
#include <urjtag/chain.h>
#include <urjtag/bus.h>
#include <urjtag/cable.h>

#include "2wigfuncs.h"
#include "2wiglet.h"

extern int32_t debug;

// initialise the JTAG chain
//
urj_chain_t *initjtagchain(char *cable_name) {
    const urj_cable_driver_t **d;
    urj_cable_t *cable;
    urj_chain_t *chain;

    chain = urj_tap_chain_alloc();
    if (chain == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL, "Error: %s\n", urj_error_describe());
        return NULL;
    }

    urj_part_parts_free(chain->parts);
    
    if(addpart(chain) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL, "Problem with addpart()\n");
        return NULL;
    }        

    urj_log(debug, "%s %s part created\n", urj_tap_chain_active_part(chain)->manufacturer, 
            urj_tap_chain_active_part(chain)->part);

    urj_log(URJ_LOG_LEVEL_DEBUG, "Searching for cable driver: %s\n", cable_name);
    for (d = (const urj_cable_driver_t **) urj_tap_cable_drivers; *d != NULL; d++) {
        urj_log(debug, "%s ", (*d)->name);
        if (strcasecmp((*d)->name, cable_name) == 0)
            break;        
    }
    urj_log(debug, "\n");
    if (*d == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL, "Cable not found.\n");
        return NULL;
    }

    switch((*d)->device_type) {
        case URJ_CABLE_DEVICE_OTHER :
            urj_log(URJ_LOG_LEVEL_NORMAL, "Found other cable driver for %s - TODO\n", cable_name);
            return NULL;
            break;
        case URJ_CABLE_DEVICE_PARPORT :
            urj_log(URJ_LOG_LEVEL_NORMAL, "Found parallel port cable %s - TODO\n", cable_name);
            return NULL;
            break;
        case URJ_CABLE_DEVICE_USB :
            urj_log(URJ_LOG_LEVEL_NORMAL, "Found USB cable driver for %s\n", cable_name);
            urj_log(debug, "Attempting to connect to USB cable\n");
            cable = urj_tap_cable_usb_connect(chain, *d, NULL);
            break;
        default :
            urj_log(URJ_LOG_LEVEL_NORMAL, "Unknown cable type\n");
            return NULL;
            break;            
    }

    if (cable == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL, "Error: %s\n", urj_error_describe());
        return NULL;
    }

    urj_log(URJ_LOG_LEVEL_NORMAL, "Connected to %s cable\n", (*d)->name);
    
    return(chain);
} 

// repeatedly read the JTAG DATA OUT register on the target and displays
// the value in hexadecimal
int32_t outreadtest(urj_chain_t *chain) {
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;

    urj_part_parts_set_instruction(chain->parts, "SELDATAOUT");
    urj_tap_chain_shift_instructions(chain);
    urj_log(debug,"Shifting in instruction %s\n", "SELDATOOUT");
  
    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return -1;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return -1;
    }
    dr = active_ir->data_register;
    if (dr == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"%s: instruction without active data register", "dr");
        return -1;
    }

    while(!kbhit()) {
        urj_tap_chain_shift_data_registers(chain, 1);
        urj_log(URJ_LOG_LEVEL_NORMAL," %0*" PRIx64 "\n", dr->out->len / 4, 
            urj_tap_register_get_value(dr->out));
    } 
    return 0;
}

// Write a random value into the JTAG DATAIN register of the target and
// then read it immediately back.  Only outputs if the values written
// to DATAIN and then read from DATAIN are different
int32_t inreadwritetest(urj_chain_t *chain) {
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;
    uint64_t ourrand = 0, oldrand =0, readval=0;
    struct timeval time;

    urj_part_parts_set_instruction(chain->parts, "SELDATAIN");
    urj_tap_chain_shift_instructions(chain);
    urj_log(debug,"Shifting in instruction %s\n", "SELDATAIN");
  
    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return -1;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return -1;
    }
    dr = active_ir->data_register;
    if (dr == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"%s: instruction without active data register", "dr");
        return -1;
    }

    gettimeofday(&time, NULL);
    srand((time.tv_sec * 1000) + (time.tv_usec / 1000)); // seed

    while(!kbhit()) {
        urj_tap_register_set_value (dr->in, ourrand);
        urj_tap_chain_shift_data_registers(chain, 1);
        readval = urj_tap_register_get_value(dr->out);
        if(readval != oldrand)
            urj_log(URJ_LOG_LEVEL_NORMAL,"expected: %08" PRIx64 "   got: %08" PRIx64 "\n", 
                                oldrand, urj_tap_register_get_value(dr->out));
        oldrand = ourrand;
        ourrand = (uint64_t)(lrand48() + lrand48());  // 0<=n<=2^32;
    }
    return 0;
}


// monitor the JTAG DATA OUT register. Only outputs when the DATA OUT register 
// value changes
int32_t outchangetest(urj_chain_t *chain) {
    struct timeval tvbegin, tvend;
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;
    uint64_t i, oldval=0, val=0, changes=0;

    urj_part_parts_set_instruction(chain->parts, "SELDATAOUT");
    urj_tap_chain_shift_instructions(chain);
    urj_log(debug,"Shifting in instruction %s\n", "SELDATOOUT");
  
    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return -1;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return -1;
    }
    dr = active_ir->data_register;
    if (dr == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"%s: instruction without active data register", "dr");
        return -1;
    }

    gettimeofday(&tvbegin, NULL);
    for(i=0; !kbhit(); i++) {
        urj_tap_chain_shift_data_registers(chain, 1);
        val = urj_tap_register_get_value(dr->out);
        if(oldval!=val) {
            gettimeofday(&tvend, NULL);
            urj_log(URJ_LOG_LEVEL_NORMAL,"%8" PRIi64 ": %08" PRIx64 " changed to %08" PRIx64 
                "  delta t = %" PRIi64 " msec\n", changes+1, oldval, val, tvsub(&tvbegin,&tvend)/1000);
            oldval=val;
            changes++;
            tvbegin=tvend;
        }
    }
    urj_log(URJ_LOG_LEVEL_NORMAL,"There were %" PRIi64 " changes in %" PRIi64 " loops\n", changes, i);
    return 0;
}

// -----------------------------------------------------------------------
// Verifies that the target is ready for JTAG L1 boot
// reports receipt of L1 boot magic number; the MMIO_BASE; DRAM_LO; DRAM_HI; and DRAM_CLIMIT
int32_t boottest(urj_chain_t *chain) {

    struct timeval tvbegin = {0,0}, tvend = {0,0};
    uint64_t val = 0;

    urj_log(URJ_LOG_LEVEL_NORMAL,"Waiting for L1BOOT_READY from TM32 target\n");

// get L1 BOOT READY code from target (with 8 second timeout)
    gettimeofday(&tvbegin, NULL);
    while(1) {        
        gettimeofday(&tvend, NULL);
        if((val = scanofullout(chain)) < 0) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"Error getting boot ready code. Aborting\n");
            return -1;
        }
        // right shift one bit to drop the CTRL1.ofull bit
        val = (val >> 1);

//        showctrlflags(chain,debug);
        if(tvsub(&tvbegin,&tvend) / 1000 > BOOTREADYWAITTIME) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"Timeout waiting for L1 Boot Ready (%08" PRIx64 ")\n", 
                    (uint64_t) START_L2_LOAD_V1);
            return -1;
        }
        if(kbhit()) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"\nKey press detected. Aborting\n");
            return -1;
        }
        if(val == START_L2_LOAD_V1) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"\nL1BOOT_READY  <- %08" PRIx64 " \n", val);
            break;
        } 
    }

// set ifull bit of CTRL2
    if(setifull(chain, IFULL) < 0) {
       urj_log(URJ_LOG_LEVEL_NORMAL,"setting CTRL2.ifull failed\n");
        return -1;
    }
    urj_log(debug,"set ifull\n");

    showctrlflags(chain,debug);

// get MMIO_BASE from target
    urj_log(URJ_LOG_LEVEL_DEBUG,"getting MMIO_BASE\n");
    if((val = scanofullout(chain)) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Error getting MMIO_BASE. Aborting\n");
        return -1;
    }
// right shift one bit to drop the CTRL1.ofull bit
    val = (val >> 1);

    urj_log(URJ_LOG_LEVEL_NORMAL,"MMIO_BASE     <- %08" PRIx64 "  (expected: 1be00000)\n", val);

    showctrlflags(chain,debug);

// set ifull bit of CTRL2
    if(setifull(chain, IFULL) < 0) {
       urj_log(URJ_LOG_LEVEL_NORMAL,"setting CTRL2.ifull failed\n");
        return -1;
    }
    urj_log(URJ_LOG_LEVEL_DEBUG,"set ifull\n");

    showctrlflags(chain,debug);

// get DRAM_LO from target
    urj_log(URJ_LOG_LEVEL_DEBUG,"getting DRAM_LO\n");
    if((val = scanofullout(chain)) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Error getting DRAM_LO. Aborting\n");
        return -1;
    }
// right shift one bit to drop the CTRL1.ofull bit
    val = (val >> 1);

    urj_log(URJ_LOG_LEVEL_NORMAL,"DRAM_LO       <- %08" PRIx64 "  (expected: 40000000)\n", val);

    showctrlflags(chain,debug);

// set ifull bit of CTRL2
    if(setifull(chain, IFULL) < 0) {
       urj_log(URJ_LOG_LEVEL_NORMAL,"setting CTRL2.ifull failed\n");
        return -1;
    }
    urj_log(URJ_LOG_LEVEL_DEBUG,"set ifull\n");

    showctrlflags(chain,debug);

// get DRAM_HI from target
    urj_log(URJ_LOG_LEVEL_DEBUG,"getting DRAM_HI\n");
    if((val = scanofullout(chain)) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Error getting DRAM_HI. Aborting\n");
        return -1;
    }

// right shift one bit to drop the CTRL1.ofull bit
    val = (val >> 1);

    urj_log(URJ_LOG_LEVEL_NORMAL,"DRAM_HI       <- %08" PRIx64 "  (expected: 44000000)\n", val);

    showctrlflags(chain,debug);

// set ifull bit of CTRL2
    if(setifull(chain, IFULL) < 0) {
       urj_log(URJ_LOG_LEVEL_NORMAL,"setting CTRL2.ifull failed\n");
        return -1;
    }
    urj_log(URJ_LOG_LEVEL_DEBUG,"set ifull\n");

    showctrlflags(chain,debug);

// get DRAM_CLIMIT target
    urj_log(URJ_LOG_LEVEL_DEBUG,"getting DRAM_CLIMIT\n");
    if((val = scanofullout(chain)) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Error getting DRAM_CLIMIT. Aborting\n");
        return -1;
    }

// right shift one bit to drop the CTRL1.ofull bit
    val = (val >> 1);

    urj_log(URJ_LOG_LEVEL_NORMAL,"DRAM_CLIMIT   <- %08" PRIx64 "  (expected: 44000000)\n", val);

    showctrlflags(chain,debug);

    return 0;
}

// -------------------------------------------------------------------------------------
// download a count of 'codesize' bytes to target at load address loadaddr, 
// then start execution from the load address
int32_t bootfile(urj_chain_t *chain, uint8_t *membuf, uint32_t loadaddr, int32_t codesize) {

    uint64_t currentword = 0;
    float duration = 0.0, proportionleft = 0.0;
    uint32_t pcchecksum = 0, targetchecksum = 0;
    int64_t targetcodecnt = 0, val = 0;
    int32_t pccodecnt = codesize;
    struct timeval tvbegin = {0,0}, tvend = {0,0}, tvnow = {0,0};
    uint8_t *byteptr = NULL;
    
    if(boottest(chain) < 0)
        return -1;

    urj_log(URJ_LOG_LEVEL_DEBUG,"\nDownloading %d bytes to address %08x: \n", codesize, loadaddr);

    showctrlflags(chain,debug);

// scan in load address (and set CTRL2.ifull)
    urj_log(URJ_LOG_LEVEL_DEBUG,"scanning in load address\n");
    if(scanifullin(chain, loadaddr) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Scanning in load address failed\n");
        return -1;
    }
    urj_log(URJ_LOG_LEVEL_NORMAL,"LOAD ADDRESS  -> %08x\n", loadaddr);

    showctrlflags(chain,debug);

// ------------------------------------------------

// clear CTRL1.ofull ready for next handshake
    urj_log(URJ_LOG_LEVEL_DEBUG,"clearing ofull\n");
    if(!setofull(chain, OFULL|SLEEPLESS)) {
        urj_log(URJ_LOG_LEVEL_DEBUG,"clearing CTRL1.ofull failed\n");
        return -1;
    }
    showctrlflags(chain,debug);

    urj_log(URJ_LOG_LEVEL_DEBUG,"cleared ofull\n");

// scan the code size into IFULLIN
    urj_log(URJ_LOG_LEVEL_DEBUG,"Scanning in code size\n");
    if(scanifullin(chain, codesize) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Scanning in code size failed\n");
        return -1;
    }
    showctrlflags(chain,debug);
    urj_log(URJ_LOG_LEVEL_NORMAL,"CODE SIZE     -> %08x (%d)\n\n", codesize, codesize);


// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  the main download loop
// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;

    part = urj_tap_chain_active_part(chain);
    active_ir = part->active_instruction;
    dr = active_ir->data_register;

    urj_part_parts_set_instruction(chain->parts, "SELIFULLIN");
    urj_tap_chain_shift_instructions(chain);

//  showctrlflags(chain,debug);

    urj_log(URJ_LOG_LEVEL_NORMAL,"Started L2 download..\n");
    gettimeofday(&tvbegin, NULL);
    pcchecksum = 0;
    currentword = 0;
    byteptr = membuf;

    while (pccodecnt > 0) {

        if (kbhit()) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"\nKey press detected. Aborting\n");
            return -1;
        }

// read 32-bit word from memory buffer (words assumed to be in little endian format)

        currentword = 0;
        currentword |= (int64_t) (*byteptr++);
        currentword |= (int64_t) ((*byteptr++) << 8);
        currentword |= (int64_t) ((*byteptr++) << 16);
        currentword |= (int64_t) ((*byteptr++) << 24);       

//      urj_log(URJ_LOG_LEVEL_NORMAL, "currentword = %08" PRIx32 "\n", (uint32_t)currentword);

//      showctrlflags(chain, debug);

// scan the 32-bit word into IFULLIN (also setting CTRL2.ifull bit)

        urj_tap_register_set_value (dr->in, (currentword << 1) | 1 );
        urj_tap_chain_shift_data_registers(chain, 1);

//      urj_log(URJ_LOG_LEVEL_DEBUG,
//          "Scanned in 32-bit word,set CTRL2.ifull = 0x%0" PRIx64 "\n", currentword);

//      showctrlflags(chain, debug);

// update the local checksum

        pcchecksum += (currentword & 0xff);
        pcchecksum += ((currentword>>8)  & 0xff);
        pcchecksum += ((currentword>>16) & 0xff);
        pcchecksum += ((currentword>>24) & 0xff);

// scan the current code_size counter from DATAOUT on the target

//      urj_log(URJ_LOG_LEVEL_DEBUG,"Scanning out code counter\n");

// report the download count
// only report the count every 0x1000 bytes so as not to slow down the transfer
        if(!((pccodecnt + pccodecnt % 4) % 0x1000)) {
 
            if((targetcodecnt = scanofullout(chain)) < 0) {
                urj_log(URJ_LOG_LEVEL_NORMAL,"\nScanning out code counter failed. Aborting\n");
                return -1;
            }            
            targetcodecnt = (targetcodecnt >> 1); // right shift one bit to drop the CTRL1.ofull bit

            if(pccodecnt != targetcodecnt) {
                urj_log(URJ_LOG_LEVEL_NORMAL, "\nPC and TM32 Target have lost sync. Aborting\n");
                return -1;
            }

            gettimeofday(&tvnow, NULL);
            duration = (float)(tvsub(&tvbegin,&tvnow) / 1000);
            proportionleft = (float) (pccodecnt) / (float)(codesize);
            urj_log(URJ_LOG_LEVEL_NORMAL,
                "TM32_COUNT=%08" PRIx64 "  (%02.2f%% done, %.fm%02.fs left, %2.2fkB/s)",
                (uint64_t) targetcodecnt, (1.0 - proportionleft) * 100.0,
                (proportionleft / (1.0 - proportionleft) * duration / 1000 / 60),
                fmod(proportionleft / (1.0 - proportionleft) * duration / 1000,60),
                (codesize - pccodecnt) / duration);

            urj_log(URJ_LOG_LEVEL_NORMAL,"        \r");
            urj_part_parts_set_instruction(chain->parts, "SELIFULLIN");
            urj_tap_chain_shift_instructions(chain);
        }

//        showctrlflags(chain, debug);

// decrement code_size counter
        pccodecnt -= 4;

    } // end while loop


// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
// target sets ifull to indicate download is complete and checksum is ready

    urj_log(URJ_LOG_LEVEL_NORMAL,"L2 load done.                                             \n");

// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

// calculate and compare checksums

    pcchecksum |= 1;    

// scan the final checksum value from DATAOUT on the target

    urj_log(URJ_LOG_LEVEL_DEBUG,"Scanning out checksum\n");
    
    if((targetchecksum = scanofullout(chain)) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Scanning out checksum failed. Aborting\n");
        return -1;
    }
// right shift one bit to drop the CTRL1.ofull bit
    targetchecksum = (targetchecksum >> 1);

    showctrlflags(chain, debug);

// wait until CTRL1.ofull is clear
    do { 
        urj_log(URJ_LOG_LEVEL_DEBUG,"waiting for CTRL1.ofull bit to clear\n");
        val = getofull(chain);
        if(kbhit())
            return -1;
    } while(val & OFULL);

    showctrlflags(chain, debug);

    urj_log(URJ_LOG_LEVEL_DEBUG,"ofull is clear\n");

//    targetchecksum = targetchecksum >> 1;

    urj_log(URJ_LOG_LEVEL_NORMAL,"Comparing checksums: ");
    urj_log(URJ_LOG_LEVEL_NORMAL,"PC MONITOR=%08x, TM32 TARGET=%08x\n",pcchecksum, targetchecksum);

// compare checksums.. if different then abort

    if(pcchecksum != targetchecksum) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Checksums bad! Aborting!\n");
        return -1;
    }

// checksums match

    urj_log(URJ_LOG_LEVEL_NORMAL,"Checksums good.\n");

// calculate duration of download
    
    gettimeofday(&tvend, NULL);
    duration = (float) tvsub(&tvbegin,&tvend) / 1000;

    urj_log(URJ_LOG_LEVEL_NORMAL,"Download complete\n");
    urj_log(URJ_LOG_LEVEL_NORMAL,"Elapsed time %.2f secs (avg %.2fkB/sec)\n",
        duration/1000, (float) (codesize/1024/(duration/1000)));

// Send JUMP_TO_L2_CODE

    urj_log(URJ_LOG_LEVEL_NORMAL,"Starting TM32 execution at %08x\n", loadaddr);

    if(scanifullin(chain, JUMP_TO_L2_CODE) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Scanning in JUMP_TO_L2_CODE failed. Aborting\n");
        return -1;
    }

    return 0;
}

int32_t jtagconsole(urj_chain_t *chain) {
    int64_t val = 0;
    uint8_t i = 0, c = 0;
    urj_log(URJ_LOG_LEVEL_NORMAL,"JTAG Console started:\n");
    urj_log(URJ_LOG_LEVEL_NORMAL,"-------------------------------------------------------\n\n");
    while(1) {
        if((val = scanofullout(chain)) < 0) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"Error scanning ofullout. Aborting\n");
            return -1;
        }
        val = val >> 1;     // drop the CTRL1.ofull bit

        if(kbhit()) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"\nKey press detected. Aborting\n");
            return -1;
        }

        if(getctrlbits(chain) & OFULLFLAG) {
            if(setifull(chain, IFULL)<0) {
                urj_log(URJ_LOG_LEVEL_NORMAL,"clearing CTRL2.ifull failed. Aborting\n");
                return -1;
            }

            for(i=0;i<4;i++) {
                c = (uint8_t)(val >> (i*8));
                urj_log(URJ_LOG_LEVEL_NORMAL,"%c", c);                
            }
            showctrlflags(chain, debug);
        }

    }
    return 0;
}

// wait for target to set CTRL1.ofull
//
int32_t waitofullset(urj_chain_t *chain) {
    struct timeval tvbegin = {0,0}, tvend = {0,0};
    uint64_t i = 0;

    gettimeofday(&tvbegin, NULL);
    while(! (i & OFULL)) {
        gettimeofday(&tvend, NULL);
        if(tvsub(&tvbegin,&tvend) / 1000 > BOOTREADYWAITTIME) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"Timeout waiting for target to set CTRl1.ofull\n");
            return -1;
        }
        if(kbhit()) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"\nKey press detected. Aborting\n");
            return -1;
        }
        i = getofull(chain); // alternative to getofull2()
//      urj_log(URJ_LOG_LEVEL_DEBUG,"getofull() returned 0x%02" PRIx64 "\n" , i);
//      showctrlflags(chain,debug);
        if(i<0) {
            urj_log(URJ_LOG_LEVEL_NORMAL, "Error from getofull(): %lx \n", i);
            return -1;
        }

        switch(i & OFULL ) {
            case 0:     // urj_log(URJ_LOG_LEVEL_DEBUG, "waiting for CTRL1.ofull: i=%08" PRIx64 "\n",i);
                        break;
            case OFULL: // urj_log(URJ_LOG_LEVEL_DEBUG, "CTRL1.ofull set by target: %lx \n", i);
                        return 0;
                        break;              
            default:    urj_log(URJ_LOG_LEVEL_NORMAL,"Error from getofull(): %lx \n", i);
                        return -1;
        }
    }
    return -1;
}

// wait for target to clear CTRL2.ifull
//
int32_t waitifullclear(urj_chain_t *chain) {
    struct timeval tvbegin = {0,0}, tvend = {0,0};
    uint64_t i = 1;

    gettimeofday(&tvbegin, NULL);
    while(i) {
        gettimeofday(&tvend, NULL);
        if(tvsub(&tvbegin,&tvend) / 1000 > BOOTREADYWAITTIME) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"Timeout waiting for target to clear CTRl2.ifull\n");
            return -1;
        }
        if(kbhit()) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"\nKey press detected. Aborting\n");
            return -1;
        }
        i=getifull2(chain);        
        urj_log(URJ_LOG_LEVEL_DEBUG,"getifull2() returned 0x%lx\n" , i);
        if(i < 0) {
            urj_log(URJ_LOG_LEVEL_NORMAL, "Error from getifull2(): 0x%lx \n", i);
            return -1;
        }        
//        showctrlflags(chain,debug);
        switch(i & 4) {     // CTRL2.ifull flag found in bit 3
            case 0:     urj_log(URJ_LOG_LEVEL_DEBUG, "target has cleared CTRL2.ifull: 0x%lx \n", i);
                        return 0;
                        break;
            case 4:     urj_log(URJ_LOG_LEVEL_DEBUG, "CTRL2.ifull still set: 0x%lx \n", i);
                        break;
            default:    urj_log(URJ_LOG_LEVEL_NORMAL, "Unknown error from getifull2(): 0x%lx \n", i);
                        return -1;
        }
    }
    return 0;
}

// wait for target to set CTRL2.ifull using getifull2()
//
int32_t waitifullset(urj_chain_t *chain) {
    struct timeval tvbegin = {0,0}, tvend = {0,0};
    uint64_t i = 1;

    gettimeofday(&tvbegin, NULL);
    while(i) {
        gettimeofday(&tvend, NULL);
        if(tvsub(&tvbegin,&tvend) / 1000 > BOOTREADYWAITTIME) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"Timeout waiting for target to set CTRl2.ifull\n");
            return -1;
        }
        if(kbhit()) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"\nKey press detected. Aborting\n");
            return -1;
        }
        i=getifull2(chain);        
        urj_log(URJ_LOG_LEVEL_DEBUG,"getifull2() returned 0x%lx\n" , i);
        if(i < 0) {
            urj_log(URJ_LOG_LEVEL_NORMAL, "Error from getifull2(): 0x%lx \n", i);
            return -1;
        }        
//        showctrlflags(chain,debug);
//                  CTRL2.ifull flag found in bit 3 of captured output from instruction shift in
        switch(i & 4) {    
            case 4:     urj_log(URJ_LOG_LEVEL_DEBUG, "target has set CTRL2.ifull: 0x%lx \n", i);
                        return 0;
                        break;
            case 0:     urj_log(URJ_LOG_LEVEL_DEBUG, "CTRL2.ifull still clear: 0x%lx \n", i);
                        break;
            default:    urj_log(URJ_LOG_LEVEL_NORMAL, "Unknown error from getifull2(): 0x%lx \n", i);
                        return -1;
        }
    }
    return 0;
}

// set the value of the ifull bit of the CTRL2 register
int32_t setifull(urj_chain_t *chain, uint64_t val) {
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;

    urj_part_parts_set_instruction(chain->parts, "SELCTRL2");
//    urj_tap_chain_shift_instructions(chain);
    urj_tap_chain_shift_instructions_mode (chain, 1, 1, URJ_CHAIN_EXITMODE_IDLE);   // capture output
    urj_log(debug,"Shifting in instruction %s\n", "SELCTRL2");
  
    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return -1;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return -1;
    }
    dr = active_ir->data_register;
    if (dr == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"%s: instruction without active data register", "dr");
        return -1;
    }
//    showctrlflags(chain,debug);

    urj_tap_register_set_value (dr->in, val);     // set/clear the one usable bit of CTRL2
    urj_tap_chain_shift_data_registers(chain, 1);
    return 0;
}

// get the contents of the CTRL1 register (for the ofull bit)

int32_t getofull(urj_chain_t *chain) {
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;

    urj_part_parts_set_instruction(chain->parts, "SELCTRL1");
//    urj_tap_chain_shift_instructions(chain);
    urj_tap_chain_shift_instructions_mode (chain, 1, 1, URJ_CHAIN_EXITMODE_IDLE);   // capture output
//    urj_log(debug,"Shifting in instruction %s\n", "SELCTRL1");
  
    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return -1;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return -1;
    }
    dr = active_ir->data_register;
    if (dr == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"%s: instruction without active data register", "dr");
        return -1;
    }
//  showctrlflags(chain,debug);

    urj_tap_chain_shift_data_registers(chain, 1);
    return(urj_tap_register_get_value(dr->out));
}

// SECOND version of getofull function. 
// Get the contents of the CTRL1 register (for the ofull bit)
// only scan in the instruction, and then read bits from captured output

int32_t getofull2(urj_chain_t *chain) {
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;

    urj_part_parts_set_instruction(chain->parts, "SELCTRL1");
    urj_tap_chain_shift_instructions_mode (chain, 1, 1, URJ_CHAIN_EXITMODE_IDLE);   // capture output
    urj_log(debug,"Shifting in instruction %s\n", "SELCTRL1");
  
    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return -1;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return -1;
    }
    dr = active_ir->data_register;
    if (dr == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"%s: instruction without active data register", "dr");
        return -1;
    }
//  showctrlflags(chain,debug);
        
    return((getctrlbits(chain) >> 3) & OFULL);
}



// get the ifull bit of the CTRL2 register
// we can do this non-destructively by scanning in zero
int32_t getifull(urj_chain_t *chain) {
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;

    urj_part_parts_set_instruction(chain->parts, "SELCTRL2");
//    urj_tap_chain_shift_instructions(chain);
    urj_tap_chain_shift_instructions_mode (chain, 1, 1, URJ_CHAIN_EXITMODE_IDLE);   // capture output
    urj_log(debug,"Shifting in instruction %s\n", "SELCTRL2");
  
    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return -1;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return -1;
    }
    dr = active_ir->data_register;
    if (dr == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"%s: instruction without active data register", "dr");
        return -1;
    }
//  showctrlflags(chain,debug);

//    urj_tap_register_set_value (dr->in, 0);     // scan in 0 to CTRL2 for non-destructive read
    urj_tap_chain_shift_data_registers(chain, 1);
    return(urj_tap_register_get_value(dr->out));
}


// 2nd version of getifull() - get the ifull bit of the CTRL2 register
// -- this version captures the ifull bit value from the output captured from shifting in
// an instruction rather than from using a SELCTRL2 instruction and the shifting out the data register
// This saves a few ticks of the JTAG clock and is more efficient

int32_t getifull2(urj_chain_t *chain) {
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    uint64_t val = 0;

    urj_part_parts_set_instruction(chain->parts, "SELCTRL2");
    urj_tap_chain_shift_instructions_mode (chain, 1, 1, URJ_CHAIN_EXITMODE_IDLE);   // capture output
    urj_log(debug,"Shifting in instruction %s\n", "SELCTRL2");

    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return -1;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return -1;
    }

    val = urj_tap_register_get_value(urj_tap_chain_active_part(chain)->active_instruction->out);

    urj_log(URJ_LOG_LEVEL_DEBUG,"getifull2() - val = %0lx\n", val);

    return((int32_t) val);
}


// 3rd version - get the state of the CTRL1 and CTRL2 registers.
// -- this version doesnt touch the JTAG chain. It returns the last known state of the control
// registers as they were captured from the output of the last instruction shift in.  Hence the
// control flags may be out of date.  Nevertheless, the function is useful insofar as it places
// no load on the JTAG interface
//
// N.B. The ifull, ofull and sleepless bits are not in the bit positions stated in Philips literature.
// e.g. see top of page 39-815 in the PNX8526 User Manual (Rev.01 8 Oct 2003). The information there
// seems incorrect.
//
// This is what was actually discovered..
//
// CTRL1.sleepless is in bit 0 (1)
// CTRL2.ifull     is in bit 2 (4)
// CTRL1.ofull     is in bit 4 (0x10)

int32_t getctrlbits(urj_chain_t *chain) {
    urj_part_t *part;
    uint64_t val = 0;

    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return -1;
    }

    if (part->active_instruction == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return -1;
    }

    val = urj_tap_register_get_value(urj_tap_chain_active_part(chain)->active_instruction->out);

    urj_log(URJ_LOG_LEVEL_DEBUG,"getctrlbits() - val = %0lx\n", val);

    return((int32_t) val);
}

// set the value of the ofull bits of the CTRL1 register
int32_t setofull(urj_chain_t *chain, uint64_t val) {
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;

    urj_part_parts_set_instruction(chain->parts, "SELCTRL1");
//    urj_tap_chain_shift_instructions(chain);
    urj_tap_chain_shift_instructions_mode (chain, 1, 1, URJ_CHAIN_EXITMODE_IDLE);   // capture output
    urj_log(debug,"Shifting in instruction %s\n", "SELCTRL1");
  
    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return 0;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return 0;
    }
    dr = active_ir->data_register;
    if (dr == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"%s: instruction without active data register", "dr");
        return 0;
    }
//  showctrlflags(chain,debug);;

    urj_tap_register_set_value (dr->in, val & 3);     // set/clear the two bits of CTRL1 (OFULL|SLEEPLESS)
    urj_tap_chain_shift_data_registers(chain, 1);
    return 1;
}

// scan DATAOUT register from target
uint64_t scandataout(urj_chain_t *chain) {
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;

    uint64_t val = 0;

    urj_part_parts_set_instruction(chain->parts, "SELDATAOUT");
 //   urj_tap_chain_shift_instructions(chain);
    urj_tap_chain_shift_instructions_mode (chain, 1, 1, URJ_CHAIN_EXITMODE_IDLE);   // capture output
    urj_log(debug,"Shifting in instruction %s\n", "SELDATAOUT");
  
    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return 0;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return 0;
    }

//  showctrlflags(chain,debug);

    dr = active_ir->data_register;
    if (dr == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"%s: instruction without active data register", "dr");
        return 0;
    }
    urj_tap_chain_shift_data_registers(chain, 1);
    val = urj_tap_register_get_value(dr->out);
    return(val);
}

// scan DATAIN register into target
int32_t scandatain(urj_chain_t *chain, uint64_t val) {
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;

    urj_part_parts_set_instruction(chain->parts, "SELDATAIN");
//    urj_tap_chain_shift_instructions(chain);
    urj_tap_chain_shift_instructions_mode (chain, 1, 1, URJ_CHAIN_EXITMODE_IDLE);   // capture output

    urj_log(debug,"Shifting in instruction %s\n", "SELDATAIN");

    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return -1;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return -1;
    }

//  showctrlflags(chain,debug);

    dr = active_ir->data_register;
    if (dr == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"%s: instruction without active data register", "dr");
        return -1;
    }

    urj_tap_register_set_value (dr->in, val);
    urj_tap_chain_shift_data_registers(chain, 1);
    return 0;
}


// scan 33-bit IFULLIN register (DATAIN and CTRL2.ifull) into target
//
int32_t scanifullin(urj_chain_t *chain, uint64_t val) {
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;

    urj_part_parts_set_instruction(chain->parts, "SELIFULLIN");
    urj_tap_chain_shift_instructions(chain);
//    urj_tap_chain_shift_instructions_mode (chain, 1, 1, URJ_CHAIN_EXITMODE_IDLE);   // capture output

//    urj_log(debug,"Shifting in instruction %s\n", "SELIFULLIN");

    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return -1;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return -1;
    }

//  showctrlflags(chain,debug);

    dr = active_ir->data_register;
    if (dr == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"%s: instruction without active data register", "dr");
        return -1;
    }

// left shift and set the CTRL2.ifull bit

    val = ((val << 1) | 1);

    urj_tap_register_set_value (dr->in, val);
//    urj_log(URJ_LOG_LEVEL_DEBUG,"IFULLIN value = 0x%" PRIx64 " (%ld)\n", urj_tap_register_get_value(dr->in), urj_tap_register_get_value(dr->in));
    urj_tap_chain_shift_data_registers(chain, 1);
    return 0;
}

// scan 33-bit OFULLOUT register (DATAOUT and CTRL1.ofull) from target
//
int64_t scanofullout(urj_chain_t *chain) {
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;
    uint64_t val = 0;

    urj_part_parts_set_instruction(chain->parts, "SELOFULLOUT");
//    urj_tap_chain_shift_instructions(chain);
    urj_tap_chain_shift_instructions_mode (chain, 1, 1, URJ_CHAIN_EXITMODE_IDLE);   // capture output

//    urj_log(debug,"Shifting in instruction %s\n", "SELOFULLOUT");

    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return -1;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return -1;
    }

    dr = active_ir->data_register;
    if (dr == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"%s: instruction without active data register", "dr");
        return -1;
    }

    urj_tap_chain_shift_data_registers(chain, 1);

    val = urj_tap_register_get_value (dr->out);

// right shift one bit to drop the CTRL1.ofull bit

//  urj_log(URJ_LOG_LEVEL_DEBUG,"OFULLOUT bit 1 value = 0x%" PRIx64 " (%ld)\n", val&1, val&1);

//    val = (val >> 1);

//  urj_log(URJ_LOG_LEVEL_DEBUG,"OFULLOUT value = 0x%" PRIx64 " (%ld)\n", val, val);

    return val;
}

// dump the last captured state of the CTRL1.ofull, CTRL2.ifull and CTRl1.sleepless flags
//
int32_t showctrlflags(urj_chain_t *chain, uint32_t level) {

    urj_log(level,"Current ctrl flags: 0x%02lx  [%s|%s|%s]\n", 
        urj_tap_register_get_value(urj_tap_chain_active_part(chain)->active_instruction->out),
        (urj_tap_register_get_value(urj_tap_chain_active_part(chain)->active_instruction->out)
            & 0x10 ? "ofull" : "     "),
        (urj_tap_register_get_value(urj_tap_chain_active_part(chain)->active_instruction->out)
            & 4 ? "ifull" : "     "),
        (urj_tap_register_get_value(urj_tap_chain_active_part(chain)->active_instruction->out)
            & 1 ? "sleepless" : "         "));

    return 0;
}

// gets the device ID obtained from scanning in an IDCODE instruction.  Used to stabilise the chain
uint64_t getdeviceid(urj_chain_t *chain) {
    urj_part_t *part;
    urj_part_instruction_t *active_ir;
    urj_data_register_t *dr;
    uint64_t deviceid;

    urj_part_parts_set_instruction(chain->parts, "IDCODE");
    urj_tap_chain_shift_instructions(chain);
    urj_log(debug,"Shifting in instruction %s\n", "IDCODE");
    urj_tap_chain_shift_data_registers(chain, 1);
    urj_log(debug,"Shifting data registers\n");

    part = urj_tap_chain_active_part(chain);
    if (part == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"No active part in chain\n");
        return 0;
    }

    active_ir = part->active_instruction;
    if (active_ir == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"part without active instruction\n");
        return 0;
    }

    dr = active_ir->data_register;
    if (dr == NULL) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"%s: instruction without active data register", "dr");
        return 0;
    }
    
    urj_log(debug,"IDCODE = 0x%0*" PRIX64 "\n", dr->out->len / 4, urj_tap_register_get_value(dr->out));
    deviceid = urj_tap_register_get_value(dr->out);
    return(deviceid);
}

// frees the parts and JTAG chain.
void cleanup(urj_chain_t *chain) {
    urj_bus_buses_free();
    urj_tap_chain_free(chain);
    urj_log(URJ_LOG_LEVEL_NORMAL, "Freed buses and JTAG chain\n");
    chain = NULL;
}

// adds a part to the JTAG chain, including instruction and register definitions
//
int32_t addpart(urj_chain_t *chain) {

    urj_tap_register_t *reg;
    urj_part_t *part;
    int32_t c;

// create parts list if there isnt one

    if(chain->parts == NULL) {
        chain->parts = urj_part_parts_alloc();
        if(chain->parts == NULL)
            return -1;
    }

    reg = urj_tap_register_alloc(1);
    if(!reg)
        return -1;
    
    part = urj_part_alloc(reg);
    if(!part)
        return -1;

    strcpy(part->manufacturer, cpu.manufacturer);
    strcpy(part->part, cpu.partname);
    strcpy(part->stepping, cpu.stepping);

    part->instruction_length = cpu.instrlen;

    urj_log(debug, "Creating %s %s part with %d-bit instruction length\n", 
            part->manufacturer, part->part, part->instruction_length);

    urj_part_parts_add_part(chain->parts, part);
    chain->active_part = chain->parts->len - 1;
    
    urj_log(debug, "Adding register definitions to part\n");
    for(c = 0; tm32regs[c].size > 0; c++) {
        if(urj_part_data_register_define(part, tm32regs[c].name, tm32regs[c].size) != URJ_STATUS_OK) {
            urj_log(URJ_LOG_LEVEL_NORMAL, "Could not add register %s to %s part definition\n", 
                tm32regs[c].name, part->part);
            return -1;
        }
        urj_log(debug, "  Added %3d-bit %s\n", tm32regs[c].size, tm32regs[c].name);
    }

    urj_log(debug, "Adding instruction definitions to part\n");

    for(c = 0; tm32ins[c].name[0]; c++) {
        if(urj_part_instruction_define(part, tm32ins[c].name, tm32ins[c].bitstr, tm32ins[c].reg) == NULL) {
            urj_log(URJ_LOG_LEVEL_NORMAL, "Could not add instruction %s to %s definition\n",
                    tm32ins[c].name, part->part);
            return -1;
        }
        urj_log(debug,"  Added %-11s (%s) %s \n", tm32ins[c].name, tm32ins[c].bitstr, tm32ins[c].reg);
    }
    chain->total_instr_len += cpu.instrlen;
    return 0;
}

// list the JTAG cables that are available to use
void listcables(void) {
    const urj_cable_driver_t **d;
    uint32_t i = 0;
    urj_log(URJ_LOG_LEVEL_NORMAL, "Supported cables: ");
    for (d = (const urj_cable_driver_t **) urj_tap_cable_drivers; *d != NULL; d++) {
        if(!(i++ % 3))
            urj_log(URJ_LOG_LEVEL_NORMAL, "\n");
        urj_log(URJ_LOG_LEVEL_NORMAL, " %15s ", (*d)->name);
    }
    urj_log(URJ_LOG_LEVEL_NORMAL, "\n");
}

// returns 1 if keypress , otherwise 0
uint32_t kbhit(void) {
    struct timeval tv = {0,0};
    fd_set read_fd;

    FD_ZERO(&read_fd);
    FD_SET(0,&read_fd);

    if(select(1, &read_fd,NULL, NULL, &tv)<0)
        return 0;

    if(FD_ISSET(0,&read_fd)) {
        getchar();
        return 1;
    }
  return 0;
}

// return difference between t1 and t2 in usecs
uint64_t tvsub(struct timeval *t1, struct timeval *t2) {
    return((t2->tv_usec + 1000000 * t2->tv_sec) - (t1->tv_usec + 1000000 * t1->tv_sec));
}

