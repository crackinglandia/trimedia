#!/bin/bash
gcc --static -o 2wiglet 2wiglet.c 2wigfuncs.c -L  /home/michael/Documents/btbusinesshub/urjtag_asbo_006/urjtag/src/lib/.libs -L /usr/local/lib -lurjtag -lusb-1.0 -lpthread -lrt -lftdi -lusb -lreadline -ltermcap
