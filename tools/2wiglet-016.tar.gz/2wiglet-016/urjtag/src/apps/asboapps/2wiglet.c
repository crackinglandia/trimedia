#define TOOLVERSION "2Wiglet v1.6 - (c) 2012 asbokid <ballymunboy@gmail.com>\n" \
       "JTAG tool for 2Wire Routers with a TriMedia TM32 core\n"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>
#include <getopt.h>
#include <urjtag/chain.h>
#include <urjtag/bus.h>

#include "2wiglet.h"
#include "2wigfuncs.h"
#include "2wignanddriver_ares_011.h"

#define MAXPARAMLEN     1024
#define MAXPARAMNUM     10


static struct option longopts[] = {
    {"help",        no_argument, 0, 'h'},
    {"version",     no_argument, 0, 'v'},
    {"debug",       no_argument, 0, 'd'},
    {"input",       no_argument, 0, 'i'},
    {"output",      no_argument, 0, 'o'},
    {"outchange",   no_argument, 0, 'O'},
    {"bootready",   no_argument, 0, 'b'},
    {"nandtools",   no_argument, 0, 'n'},
    {"listcables",  no_argument, 0, 'l'},
    {"cable", required_argument, 0, 'c'},
    {NULL, 0, NULL, 0}
};

static char version_msg[] =    
    TOOLVERSION "\n" \
    "This program comes with asbolutely no warranty; This is free software,\n" \
    "and you are welcome to redistribute it under certain conditions:\n" \
    "GNU GPL v3 License: http://www.gnu.org/licenses/gpl.html\n\n";
    
static char usage_msg[] = 
    "USAGE:\n" \
    " -h, --help                    Displays this text\n" \
    " -v, --version                 Version information\n" \
    " -d, --debug                   Debug output\n" \
    " -i, --input                   DATA IN register read/write test\n" \
    " -o, --output                  DATA OUT register read test\n" \
    " -O, --outchange               DATA OUT register change test\n" \
    " -b, --bootready               Verify target is ready for JTAG boot\n" \
    " -B, --Boot <file>,<loadaddr>  Download file to load address and run\n" \
    " -n, --nandtools               Program/Erase/Read NAND flash device\n" \
    " -l, --listcables              List supported JTAG cables\n" \
    " -c, --cable <type> <params>   Select cable type and parameters\n\n" \
    "EXAMPLE:\n $ 2wiglet -c usbblaster -B l2bootfile.mi,0x40100000\n\n";

int32_t debug = URJ_LOG_LEVEL_DEBUG;

int main(int argc, char **argv) {

    FILE *fp = NULL;
    urj_chain_t *chain;
    uint64_t deviceid = 0, lastout = 0;
    uint32_t loadaddr = 0;
    int32_t codesize = 0;

    char *cable_name = NULL,*bootcmdline = NULL, *bootfilename = NULL, *ptr, **params =  NULL;
    uint8_t operation = 0;
    uint32_t n =0, paramnum = 0;
    uint8_t *membuf = NULL;

// parse c/l
    while (TRUE) { 
        int32_t optidx = 0;
        int8_t c = getopt_long(argc,argv,"hvdioObnlc:B:", longopts, &optidx);
        if (c == -1)
            break;

        switch (c) {
            case 'h':   fprintf(stdout, "%s%s", version_msg, usage_msg);
                        return 0;
            case 'v':   fprintf(stdout, "%s", version_msg);
                        return 0;
                        break;
            case 'd':   debug = URJ_LOG_LEVEL_NORMAL;
                        break;

            case 'c':   if(!(cable_name = (char *) malloc(strlen(optarg)))) {
                            fprintf(stderr, "memory allocation error\n");
                            goto badexit;
                        }
                        strcpy(cable_name, optarg);
                        break;
            case 'n':   operation = c;
                        break;
            case 'l':   fprintf(stdout,"%s\n", TOOLVERSION);
                        listcables();
                        return 0;
            case 'B':   if(!(bootcmdline = (char *) malloc(strlen(optarg)+1))) {
                            fprintf(stderr, "memory allocation error\n");
                            goto badexit;
                        }
                        memcpy(bootcmdline, optarg, strlen(optarg));
                        operation = c;
                        break;
            case 'i': 
            case 'o': 
            case 'O': 
            case 'b':   operation = c;
                        break;
            default : 
            case '?':   fprintf(stdout, "%s", version_msg);
                        fprintf(stderr, "%s", usage_msg);
                        goto badexit;
        }
    }
  
    if(!operation || !cable_name) {
        fprintf(stderr, "%s%s\n", version_msg, usage_msg);
        fprintf(stderr, "You must select a cable [-c] and an option from [i|o|O|n|b|B] above.\n");
        goto badexit;
    }

    fprintf(stdout,"%s\n", TOOLVERSION);

// init jtag chain

    chain = initjtagchain(cable_name);
    if(!chain) {
        urj_log(URJ_LOG_LEVEL_NORMAL, "Couldnt connect to cable %s\n", cable_name);
        goto badexit;
    }

    urj_log(URJ_LOG_LEVEL_NORMAL,"Waiting for JTAG chain to stabilise\n");
    while((deviceid = getdeviceid(chain)) != cpu.id) {          // we can check here for multiple CPU IDs
        if(deviceid != lastout) {
            urj_log(URJ_LOG_LEVEL_DEBUG," %" PRIx64 "\n", deviceid);
            lastout=deviceid;
        }
    }
    urj_log(URJ_LOG_LEVEL_NORMAL,"Received IDCODE %" PRIx64 " (%s %s) \n", 
        deviceid, cpu.manufacturer, cpu.partname); 

    switch(operation) {
        case 'i' :  urj_log(URJ_LOG_LEVEL_NORMAL,"Hit enter to stop\n");
                    inreadwritetest(chain);
                    break;
        case 'o' :  urj_log(URJ_LOG_LEVEL_NORMAL,"Hit enter to stop\n");
                    outreadtest(chain);
                    break;
        case 'O' :  urj_log(URJ_LOG_LEVEL_NORMAL,"Hit enter to stop\n");
                    outchangetest(chain);
                    break;
        case 'n' :  urj_log(URJ_LOG_LEVEL_NORMAL,"Downloading JTAG monitor (0x%x bytes) to TriMedia @ %08x\n",
                        nanddriver_ares_mi_len, DEFAULTL2LOADADDR);
                    if(bootfile(chain, nanddriver_ares_mi, DEFAULTL2LOADADDR, nanddriver_ares_mi_len) < 0)
                        return -1;
                    nandprogramtools(chain);
                    break; 
        case 'b' :  boottest(chain);
                    break;
        case 'B' :  ptr = bootcmdline;
                    params = calloc(MAXPARAMNUM, sizeof(char*));
                    for (n = 0; n < MAXPARAMNUM; ++n)
                        params[n] = malloc(strlen(bootcmdline));
                    while (sscanf(ptr, "%1024[^,]%n", params[paramnum], &n) == 1) {
                        ptr += n;
                        if (*ptr != ',')
                            break;
                        ++ptr; ++paramnum;
                    }
                    if(!(bootfilename = (char *) malloc(strlen(params[0])))) {
                        urj_log(URJ_LOG_LEVEL_NORMAL, "memory allocation error\n");
                        goto badexit;
                    }
                    memcpy(bootfilename, params[0], strlen(params[0])+1);
                    sscanf(params[1], "%x", &loadaddr);
                    if(!(fp=fopen(bootfilename, "rb"))) {
                        urj_log(URJ_LOG_LEVEL_NORMAL, "Couldnt load '%s'. Aborting\n", bootfilename);
                        goto badexit;
                    }
                    fseek(fp, 0L, SEEK_END);
                    codesize = ftell(fp);
                    fseek(fp, 0L, SEEK_SET);

                    if(!(membuf = (uint8_t *) calloc(sizeof(uint8_t), codesize + (codesize % 4)))) {
                        urj_log(URJ_LOG_LEVEL_NORMAL, "memory allocation error\n");
                        goto badexit;
                    }
                    urj_log(URJ_LOG_LEVEL_DEBUG, "calloce'd (codesize + (codesize %% 4) = %d\n", 
                        codesize + (codesize % 4));
                    if(fread(membuf,1,codesize,fp) != codesize) {
                        urj_log(URJ_LOG_LEVEL_NORMAL, "file read error\n");
                        goto badexit;
                    }
                    if(fp)
                        fclose(fp);

                    urj_log(URJ_LOG_LEVEL_NORMAL,"Download %d bytes from '%s' to %08x\n",
                              codesize, bootfilename, loadaddr);
                    if(bootfile(chain, membuf, loadaddr, codesize) < 0)
                        return -1;
                    jtagconsole(chain);        // echo contents of JTAG DATAOUT register to stdout
                    break;
    }
    cleanup(chain);

badexit:
    if(cable_name)
        free(cable_name);
    if(bootcmdline)
        free(bootcmdline);
    if(bootfilename)
        free(bootfilename);
    if(params) {
        for(n=0; params[n]; n++)
            free(params[n]);
        free(params);
    }
    if(membuf) 
        free(membuf);
    return 0;
}

