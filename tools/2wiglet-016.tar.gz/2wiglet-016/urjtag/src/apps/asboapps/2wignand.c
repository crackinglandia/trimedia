
#include <urjtag/tap_register.h>
#include <urjtag/data_register.h>
#include <urjtag/part_instruction.h>
#include <urjtag/part.h>
#include <urjtag/bus.h>
#include <urjtag/cable.h>


#include <byteswap.h>
#include <math.h>
#include <sys/time.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <inttypes.h>
#include <urjtag/chain.h>

#include "2wigfuncs.h"
#include "2wiglet.h"
#include "2wignand.h"

extern int32_t debug;

// NAND programming toolset
// bootfile is used to download the JTAG monitor for NAND Program/Erase/Read tools
// the function below is used provide a user-interface to that JTAG monitor

int32_t nandprogramtools(urj_chain_t *chain) {
    FILE *fp;
    int cmd;
    char availcmds[] = "PRQ";      // Program, Erase, Read, (readID), (JTAG monitor version), quit
    char offsetstr[10], pagecountstr[10];
    uint32_t offset = 0, pagecount = 0;
    char filename[256];
    uint8_t *membuf;
    uint32_t fbytes = 0;

    while(1) {
// get the command from stdin
        do {
            urj_log(URJ_LOG_LEVEL_NORMAL,"\nOptions:\n");
            urj_log(URJ_LOG_LEVEL_NORMAL,"  (P)rogram flash pages\n");
            urj_log(URJ_LOG_LEVEL_NORMAL,"  (E)rase flash blocks\n");
            urj_log(URJ_LOG_LEVEL_NORMAL,"  (R)ead flash pages\n");
            urj_log(URJ_LOG_LEVEL_NORMAL,"  (I)dentify flash IC\n");
            urj_log(URJ_LOG_LEVEL_NORMAL,"  (V)ersion info\n");
            urj_log(URJ_LOG_LEVEL_NORMAL,"  (Q)uit:\n");
            urj_log(URJ_LOG_LEVEL_NORMAL,"Choose (P,E,R,I,Q): ");
            cmd = toupper(getchar());
            while(getchar() != '\n');
            urj_log(URJ_LOG_LEVEL_NORMAL,"\n");
            switch(cmd) {
                case 'I':   idreadflash(chain);
                            break;
                case 'V':   jtagmonversion(chain);
                            break;
                case 'E':   eraseflash(chain, 0x1000, 0x50000);
                            break;
                case 'Q':   return 0;
            }
                            
        } while(!(strchr(availcmds, cmd)));

// get the NAND offset
        do {
            urj_log(URJ_LOG_LEVEL_NORMAL,"NAND start offset (%07x - %07x): ", 0, MAXNANDSIZE);
            gets(offsetstr);
            if(!(strstr(offsetstr,"0x")) && !(strstr(offsetstr, "0X")))
                offset = strtoul(offsetstr,NULL,16);
            else
                offset = strtoul(offsetstr,NULL,0);
                
            if(offset > MAXNANDSIZE)
                urj_log(URJ_LOG_LEVEL_NORMAL,"offset out of bounds!\n");
        } while(offset > MAXNANDSIZE || strlen(offsetstr) == 0);

// get the page count
        do {
            urj_log(URJ_LOG_LEVEL_NORMAL,"NAND page count   (%07x - %07x): ",
                offset, MAXNANDSIZE/MAINPAGESIZE);
            gets(pagecountstr);
            if(!(strstr(pagecountstr,"0x")) && !(strstr(pagecountstr, "0X")))
                pagecount = strtoul(pagecountstr,NULL,16);
            else
                pagecount = strtoul(pagecountstr,NULL,0);

            if(offset + (pagecount * FULLPAGESIZE)  > MAXNANDSIZE)
                urj_log(URJ_LOG_LEVEL_NORMAL,"page count out of range!\n");
        } while((offset + (pagecount * FULLPAGESIZE) > MAXNANDSIZE) || strlen(pagecountstr) == 0);

        switch(cmd) {
            case 'P' : // PROGRAM NAND
                do {
                    urj_log(URJ_LOG_LEVEL_NORMAL,"Image file to program to flash: ");
                    gets(filename);
                    if(!(fp = fopen(filename, "rb")))
                        urj_log(URJ_LOG_LEVEL_NORMAL,"File open error %s\n", filename);
                }
                while(!fp);
                
                if(!(membuf = malloc(pagecount * FULLPAGESIZE))) {
                    urj_log(URJ_LOG_LEVEL_NORMAL,"Memory alloc.fail in nandprogramtools()\n");
                    break;
                }

                if((fbytes = fread(membuf, 1, pagecount*FULLPAGESIZE, fp)) != pagecount*FULLPAGESIZE) {
                    urj_log(URJ_LOG_LEVEL_NORMAL,"File read error: "
                        "expected 0x%x bytes but only got 0x%x bytes\nAborting programming.\n", 
                        pagecount*FULLPAGESIZE, fbytes);
                    if(fp)
                        fclose(fp);
                    break;
                }               
                if(fp)
                    fclose(fp);
    
                urj_log(URJ_LOG_LEVEL_NORMAL,"\n");            
                // do flash program..
                urj_log(URJ_LOG_LEVEL_DEBUG,
                    "Programming (%07x+%07x) bytes from %s to NAND phy offset %07x\n",
                    pagecount * MAINPAGESIZE, pagecount * OOBSIZE, filename, offset);
                progflash(chain, membuf, offset, pagecount);
                free(membuf);
                break;

            case 'R' : // READ NAND
                do {
                    urj_log(URJ_LOG_LEVEL_NORMAL,"File to save flash data (<enter> for stdout): ");
                    gets(filename);
                    if(!strlen(filename))
                        fp = stdout;
                    else
                        if(!(fp = fopen(filename, "wb")))
                            urj_log(URJ_LOG_LEVEL_NORMAL,"File open error %s\n", filename);
                }
                while(!fp);
      
                if(!(membuf = malloc(pagecount * FULLPAGESIZE))) 
                    urj_log(URJ_LOG_LEVEL_NORMAL,"Memory alloc.fail in nandprogramtools()\n");

                // do flash read
                readflash(chain, membuf, offset, pagecount);
                
                // write membuf to disk
                if(fp==stdout)
                    dumpbuftostdout(membuf,offset,pagecount);
                else {

                    if((fbytes = fwrite(membuf,1,pagecount*FULLPAGESIZE, fp)) != pagecount*FULLPAGESIZE) {
                        urj_log(URJ_LOG_LEVEL_NORMAL,"File write error in nandprogramtools().\n"
                            "expected %d bytes but only got %d\n", pagecount*FULLPAGESIZE, fbytes);
                        break;
                    }
                }
                if(fp!=stdout)
                    fclose(fp);
                free(membuf);
                break;

            case 'E' : // ERASE NAND
                
                // do erase erase
                eraseflash(chain, offset, pagecount);

                break;
        }
    }
    return 0;
}

// ------------------------------------------------
// dumpbuftostdout() - dump read buffer to stdout
// ------------------------------------------------
void dumpbuftostdout(uint8_t *membuf, uint32_t offset, uint32_t pagecount) {
    int i, j;
    for(i=offset; i<offset+(pagecount*FULLPAGESIZE); i+=0x10) {
        printf("%07x: ",i);
        for(j=0;j<0x10;j++)
            printf("%02x ", membuf[i+j]);
        printf("\n");
    }
}

// ------------------------------------------------
// setcmdparams() - set cmd params on target
// ------------------------------------------------
int32_t setcmdparams(urj_chain_t *chain, uint32_t cmd, uint32_t offset, uint32_t pagecount) {
    uint64_t val = 0;

// scan in cmd code (PROG,READ,ERAS,RDID) (and set CTRL2.ifull)
    urj_log(URJ_LOG_LEVEL_DEBUG,"Scanning in command request: %08x\n", cmd);
    if(scanifullin(chain, cmd) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Scanning in command request failed\n");
        return -1;
    }
    urj_log(URJ_LOG_LEVEL_NORMAL,"COMMAND REQUEST -> %c%c%c%c\n", 
        cmd>>24 & 0xff,cmd>>16 & 0xff,cmd>>8 & 0xff,cmd & 0xff);

    showctrlflags(chain,debug);

// ------------------------------------------------

// scan the offset into IFULLIN
    urj_log(URJ_LOG_LEVEL_DEBUG,"Scanning in offset\n");
    if(scanifullin(chain, offset) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Scanning in offset failed\n");
        return -1;
    }
    showctrlflags(chain,debug);
    urj_log(URJ_LOG_LEVEL_NORMAL,"NAND OFFSET     -> %08x (%d)\n", offset, offset);

// ------------------------------------------------

// scan the page count into IFULLIN
    urj_log(URJ_LOG_LEVEL_DEBUG,"Scanning in page count\n");
    if(scanifullin(chain, pagecount) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Scanning in page count failed\n");
        return -1;
    }
    showctrlflags(chain,debug);
    urj_log(URJ_LOG_LEVEL_NORMAL,"NAND PAGE COUNT -> %08x (%d)\n", pagecount, pagecount);

// ------------------------------------------------

// get return value

    val=0;
    urj_log(URJ_LOG_LEVEL_DEBUG,"getting return value\n");
    do {        
        urj_log(URJ_LOG_LEVEL_DEBUG,"%09" PRIx64 "  %09" PRIx64 " %02x\n", val, (val>>1), (uint8_t)(val & 1));
        if((val = scanofullout(chain)) < 0) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"Error scanning ofullout. Aborting\n");
            return -1;
        }
    } while (!(val & 1));

// set ifull bit of CTRL2
    if(setifull(chain, IFULL) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"setting CTRL2.ifull failed\n");
        return -1;
    }

// right shift one bit to drop the CTRL1.ofull bit
    val = (val >> 1);

    showctrlflags(chain,debug);

    urj_log(URJ_LOG_LEVEL_NORMAL,"RETURN VALUE    <- %08" PRIx64 " (%c%c%c%c)\n\n", val,
        (uint8_t)(val>>24 & 0xff), (uint8_t)(val>>16 & 0xff),
        (uint8_t)(val>>8 & 0xff), (uint8_t)(val & 0xff));
    showctrlflags(chain, debug);

    return val;
}


// ------------------------------------------------
// progflash() - program page(s) from NAND flash
// ------------------------------------------------
int32_t progflash(urj_chain_t *chain, uint8_t *membuf, uint32_t offset, uint32_t pagecount) {
    uint64_t currentword = 0;
    uint32_t retval = 0, j, k;
    uint8_t *bufptr = membuf;
    struct timeval tvbegin = {0,0}, tvend = {0,0}, tvnow = {0,0};
    uint32_t pcchecksum = 0, targetchecksum = 0, currentchecksum = 0;
    float duration = 0.0;

    urj_log(URJ_LOG_LEVEL_DEBUG,"Program flash - offset %08x, pagecount %08x\n", offset, pagecount);

    retval = setcmdparams(chain, PROGCMD, offset, pagecount);
    if(retval != PROGCMD) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Program flash failure.\n");
        return -1;
    } 

    gettimeofday(&tvbegin, NULL);

    for(k=0;k<pagecount;k++) {
        for(j=0;j<FULLPAGESIZE/sizeof(int);j++) {

// read 32-bit word from memory buffer (words assumed to be in little endian format)

            currentword = 0;
            currentword |= (uint64_t)  (*bufptr++);
            currentword |= (uint64_t) ((*bufptr++) << 8);
            currentword |= (uint64_t) ((*bufptr++) << 16);
            currentword |= (uint64_t) ((*bufptr++) << 24);

            urj_log(URJ_LOG_LEVEL_DEBUG, "cword (%02x) = %08" PRIx32 "\n", j, bswap_32((uint32_t)currentword));

            showctrlflags(chain, debug);

// scan the 32-bit word into IFULLIN (also setting CTRL2.ifull bit)

            if(scanifullin(chain, currentword) < 0) {
                urj_log(URJ_LOG_LEVEL_NORMAL,"Scanning in command request failed\n");
                return -1;
            }
           showctrlflags(chain, debug);

// update the local checksum

            pcchecksum += (currentword & 0xff);
            pcchecksum += ((currentword>>8)  & 0xff);
            pcchecksum += ((currentword>>16) & 0xff);
            pcchecksum += ((currentword>>24) & 0xff);

            if((currentchecksum = scanofullout(chain)) < 0) {
                urj_log(URJ_LOG_LEVEL_NORMAL,"\nScanning out current checksum failed. Aborting\n");
                return -1;
            }            
            currentchecksum = (currentchecksum >> 1); // right shift one bit to drop the CTRL1.ofull bit
        }

// after each page, get target checksum and compare with pc checksum
        pcchecksum |=1;
        showctrlflags(chain, debug);
  
        if((targetchecksum = scanofullout(chain)) < 0) {
            urj_log(URJ_LOG_LEVEL_NORMAL,"\nScanning out target checksum failed. Aborting\n");
            return -1;
        }
        
        targetchecksum = (targetchecksum >> 1); // right shift one bit to drop the CTRL1.ofull bit

        gettimeofday(&tvnow, NULL);
        duration = (float)(tvsub(&tvbegin,&tvnow) / 1000);
        urj_log(URJ_LOG_LEVEL_NORMAL,
            "PROG %08" PRIx64 "  (%4.1f%% done, %2.2fkB/s)  ",
            (uint64_t)offset + (k*MAINPAGESIZE), (float) (k) / (float)(pagecount) * 100.0,
            k*FULLPAGESIZE/1024/(duration/1000));

        urj_log(URJ_LOG_LEVEL_DEBUG, "PCCHKSUM=%08x, TGCHKSUM=%08x ", pcchecksum,targetchecksum);
        urj_log(URJ_LOG_LEVEL_NORMAL, "%s\n", (pcchecksum==targetchecksum) ? "OK" : "BAD!");

        if(pcchecksum != targetchecksum) {
            urj_log(URJ_LOG_LEVEL_NORMAL, "\nProgram Checksum error: PCCHKSUM=%08x, TGCHKSUM=%08x. Aborting\n", pcchecksum, targetchecksum);
            return -1;
        }

// reset pcchecksum ready for next page

        pcchecksum = 0;    
    }

    urj_log(URJ_LOG_LEVEL_NORMAL,"\n");

// calculate duration and speed of download
    
    gettimeofday(&tvend, NULL);
    duration = (float) tvsub(&tvbegin,&tvend) / 1000;

    urj_log(URJ_LOG_LEVEL_NORMAL,"Program flash complete\n");
    urj_log(URJ_LOG_LEVEL_NORMAL,"Elapsed %.2f secs (avg %.2fkB/sec)\n",
        duration/1000, (float) (pagecount*FULLPAGESIZE/1024/(duration/1000)));

    return 0;
}



// ------------------------------------------------
// readflash() - program page(s) from NAND flash
// ------------------------------------------------
int32_t readflash(urj_chain_t *chain, uint8_t *membuf, uint32_t offset, uint32_t pagecount) {
    uint64_t val = 0;
    uint32_t retval = 0, i, j, k;
    uint8_t c, *bufptr = membuf;
    struct timeval tvbegin = {0,0}, tvend = {0,0}, tvnow = {0,0};
    float duration = 0.0;

    urj_log(URJ_LOG_LEVEL_DEBUG,"Read flash - offset %08x, pagecount %08x\n", offset, pagecount);

    retval = setcmdparams(chain, READCMD, offset, pagecount);
    if(retval != READCMD) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Read flash failure.\n");
        return -1;
    } 

    gettimeofday(&tvbegin, NULL);

    for(k=0;k<pagecount;k++) {
        for(j=0;j<FULLPAGESIZE;j+=4) {
            do {

                urj_log(URJ_LOG_LEVEL_DEBUG,"getting ofullout\n");
                if((val = scanofullout(chain)) < 0) {
                    urj_log(URJ_LOG_LEVEL_NORMAL,"Error getting ofullout. Aborting\n");
                    return -1;
                }
                urj_log(URJ_LOG_LEVEL_DEBUG,"%09" PRIx64 "  %08" PRIx64 " %x\n", val, val >>1, (uint8_t)(val & 1));
                if(!(val & 1))
                    urj_log(URJ_LOG_LEVEL_DEBUG, "waiting for target to ready!\n");
            } while (!(val & 1));
          
// set ifull bit of CTRL2
            if(setifull(chain, IFULL) < 0) {
                urj_log(URJ_LOG_LEVEL_NORMAL,"setting CTRL2.ifull failed\n");
                return -1;
            }
            urj_log(debug,"set ifull\n");

            showctrlflags(chain,debug);

            val = val >> 1;     // drop the CTRL1.ofull bit

            for(i=0;i<4;i++) {
                c = (uint8_t)(val >> (i*8));
                urj_log(URJ_LOG_LEVEL_DEBUG,"%02x ", c);
                *bufptr++ = c;
            }
            showctrlflags(chain, debug);
        }
    
        gettimeofday(&tvnow, NULL);
        duration = (float)(tvsub(&tvbegin,&tvnow) / 1000);
        urj_log(URJ_LOG_LEVEL_NORMAL,
            "READ %08" PRIx64 "  (%4.1f%% done, %2.2fkB/s)\n",
            (uint64_t)offset + (k*MAINPAGESIZE), (float) (k) / (float)(pagecount) * 100.0,
            k*FULLPAGESIZE/1024/(duration/1000));
    }
    urj_log(URJ_LOG_LEVEL_NORMAL,"\n");

// calculate duration and speed of download
    
    gettimeofday(&tvend, NULL);
    duration = (float) tvsub(&tvbegin,&tvend) / 1000;

    urj_log(URJ_LOG_LEVEL_NORMAL,"Read flash complete\n");
    urj_log(URJ_LOG_LEVEL_NORMAL,"Elapsed time %.2f secs (avg %.2fkB/sec)\n",
        duration/1000, (float) (pagecount*FULLPAGESIZE/1024/(duration/1000)));
    return 0;
}

// ------------------------------------------------
// eraseflash() - erase flash blocks
// ------------------------------------------------
int32_t eraseflash(urj_chain_t *chain, uint32_t offset, uint32_t pagecount) {
    int64_t val = 0;
    uint32_t retval = 0;

    urj_log(URJ_LOG_LEVEL_DEBUG,"Erase flash..\n");
    retval = setcmdparams(chain, ERASCMD, offset, pagecount);
    if(retval != ERASCMD) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Erase flash failure.\n");
        return -1;
    }

// get ERASE confirm from target
    urj_log(URJ_LOG_LEVEL_DEBUG,"getting ERASE OKAY\n");
    if((val = scanofullout(chain)) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Error getting ERASE OKAY. Aborting\n");
        return -1;
    }
// right shift one bit to drop the CTRL1.ofull bit
    val = (val >> 1);

    urj_log(URJ_LOG_LEVEL_NORMAL,"ERASE BLOCK RET <- %08" PRIx64 "\n", val);


    return 0;
}


// ------------------------------------------------
//  idreadflash() - read flash device ID 
// ------------------------------------------------
int32_t idreadflash(urj_chain_t *chain) {
    uint32_t retval = 0;
    int64_t val = 0;
    int32_t offset = -1, pagecount = -1;

    urj_log(URJ_LOG_LEVEL_DEBUG,"ID Read flash.. \n");
    retval = setcmdparams(chain, RDIDCMD, offset, pagecount);
    if(retval < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"ID Read failure.\n");
        return -1;
    }

// get FLASH ID from target
    urj_log(URJ_LOG_LEVEL_DEBUG,"getting FLASH ID\n");
    if((val = scanofullout(chain)) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Error getting FLASH ID. Aborting\n");
        return -1;
    }
// right shift one bit to drop the CTRL1.ofull bit
    val = (val >> 1);

    urj_log(URJ_LOG_LEVEL_NORMAL,"FLASH MANUFACT  <- %02X\n"
                                 "FLASH DEVICEID  <- %02X\n", 
                                (uint32_t) val & 0xff, (uint32_t) val>>8 & 0xff );

    return 0;
}


// ----------------------------------------------------------
//  jtagmonversion() - read jtag monitor version from target
// ----------------------------------------------------------
int32_t jtagmonversion(urj_chain_t *chain) {
    uint32_t retval = 0;
    int64_t val = 0;
    int32_t offset = -1, pagecount = -1;

    urj_log(URJ_LOG_LEVEL_DEBUG,"Read JTAGMON version num.. \n");
    retval = setcmdparams(chain, VERSCMD, offset, pagecount);
    if(retval < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"JTAG monitor version read failure.\n");
        return -1;
    }

// get JTAG monitor version from target
    urj_log(URJ_LOG_LEVEL_DEBUG,"getting JTAG MONITOR VERSION NUMBER\n");
    if((val = scanofullout(chain)) < 0) {
        urj_log(URJ_LOG_LEVEL_NORMAL,"Error getting JTAG MONITOR VERSION NO. Aborting\n");
        return -1;
    }
// right shift one bit to drop the CTRL1.ofull bit
    val = (val >> 1);

    urj_log(URJ_LOG_LEVEL_NORMAL,"JTAGMON VERSION <- %x.%04x\n",
                                (uint32_t) val >> 16, (uint32_t) val & 0xffff );

    return 0;
}



