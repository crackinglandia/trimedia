#ifndef URJ_CMD_SKIP_frequency
_URJ_CMD(frequency)
#endif
#ifndef URJ_CMD_SKIP_cable
_URJ_CMD(cable)
#endif
#ifndef URJ_CMD_SKIP_reset
_URJ_CMD(reset)
#endif
#ifndef URJ_CMD_SKIP_discovery
_URJ_CMD(discovery)
#endif
#ifndef URJ_CMD_SKIP_idcode
_URJ_CMD(idcode)
#endif
#ifndef URJ_CMD_SKIP_detect
_URJ_CMD(detect)
#endif
#ifndef URJ_CMD_SKIP_detectflash
_URJ_CMD(detectflash)
#endif
#ifndef URJ_CMD_SKIP_help
_URJ_CMD(help)
#endif
#ifndef URJ_CMD_SKIP_quit
_URJ_CMD(quit)
#endif
#ifndef URJ_CMD_SKIP_scan
_URJ_CMD(scan)
#endif
#ifndef URJ_CMD_SKIP_signal
_URJ_CMD(signal)
#endif
#ifndef URJ_CMD_SKIP_salias
_URJ_CMD(salias)
#endif
#ifndef URJ_CMD_SKIP_bit
_URJ_CMD(bit)
#endif
#ifndef URJ_CMD_SKIP_register
_URJ_CMD(register)
#endif
#ifndef URJ_CMD_SKIP_initbus
_URJ_CMD(initbus)
#endif
#ifndef URJ_CMD_SKIP_print
_URJ_CMD(print)
#endif
#ifndef URJ_CMD_SKIP_part
_URJ_CMD(part)
#endif
#ifndef URJ_CMD_SKIP_bus
_URJ_CMD(bus)
#endif
#ifndef URJ_CMD_SKIP_instruction
_URJ_CMD(instruction)
#endif
#ifndef URJ_CMD_SKIP_shift
_URJ_CMD(shift)
#endif
#ifndef URJ_CMD_SKIP_dr
_URJ_CMD(dr)
#endif
#ifndef URJ_CMD_SKIP_get
_URJ_CMD(get)
#endif
#ifndef URJ_CMD_SKIP_test
_URJ_CMD(test)
#endif
#ifndef URJ_CMD_SKIP_debug
_URJ_CMD(debug)
#endif
#ifndef URJ_CMD_SKIP_shell
_URJ_CMD(shell)
#endif
#ifndef URJ_CMD_SKIP_set
_URJ_CMD(set)
#endif
#ifndef URJ_CMD_SKIP_endian
_URJ_CMD(endian)
#endif
#ifndef URJ_CMD_SKIP_peek
_URJ_CMD(peek)
#endif
#ifndef URJ_CMD_SKIP_poke
_URJ_CMD(poke)
#endif
#ifndef URJ_CMD_SKIP_pod
_URJ_CMD(pod)
#endif
#ifndef URJ_CMD_SKIP_readmem
_URJ_CMD(readmem)
#endif
#ifndef URJ_CMD_SKIP_writemem
_URJ_CMD(writemem)
#endif
#ifndef URJ_CMD_SKIP_flashmem
_URJ_CMD(flashmem)
#endif
#ifndef URJ_CMD_SKIP_eraseflash
_URJ_CMD(eraseflash)
#endif
#ifndef URJ_CMD_SKIP_lockflash
_URJ_CMD(lockflash)
#endif
#ifndef URJ_CMD_SKIP_unlockflash
_URJ_CMD(unlockflash)
#endif
#ifndef URJ_CMD_SKIP_include
_URJ_CMD(include)
#endif
#ifndef URJ_CMD_SKIP_script
_URJ_CMD(script)
#endif
#ifndef URJ_CMD_SKIP_addpart
_URJ_CMD(addpart)
#endif
#ifndef URJ_CMD_SKIP_usleep
_URJ_CMD(usleep)
#endif
#ifndef URJ_CMD_SKIP_bfin
_URJ_CMD(bfin)
#endif
#ifndef URJ_CMD_SKIP_pld
_URJ_CMD(pld)
#endif
